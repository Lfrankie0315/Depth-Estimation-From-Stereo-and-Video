clear
clc
addpath(genpath('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/GCMex'));
img1 = double(imread('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/test00.jpg'));
img2 = double(imread('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/test09.jpg'));
cameras = load('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/cameras.txt');
[r1,c1,d1] = size(img1);
%[r2,c2,d2] = size(img2);
K1 = cameras(1:3,:);
R1 = cameras(4:6,:);
T1 = cameras(7,:)';
K2 = cameras(8:10,:);
R2 = cameras(11:13,:);
T2 = cameras(end,:)';
pix_num = r1*c1;
%disparity = 0:0.0001:0.0099;
disparity = 0:0.00001:0.00001*99;
sigma = 1000;
len_d = length(disparity);
%omiga = 5/(len_d-1);
%eta = 0.05*(len_d-1);
epsilon = 0.05;
%% data_term
[x,y] = meshgrid(1:c1,1:r1);
loc1 = ones(3,pix_num);
loc1(1,:) = reshape(x,1,pix_num); %img1 column location 960
loc1(2,:) = reshape(y,1,pix_num);%img2 row location 540
%loc1(1,:) = reshape(y,1,pix_num); %img1 row location 540
%loc1(2,:) = reshape(x,1,pix_num);%img2 row location 960
L = zeros(r1,c1,len_d); %L_init 
for i = 1 : len_d
    loc2 = K2*R2'*R1/K1*loc1+disparity(i).*K2*R2'*(T1-T2);
    loc2 = loc2./loc2(3,:);
    loc2 = round(loc2); % relative location in img2
    tem_img2 = zeros(pix_num,3);
    for j = 1 : length(loc2')
        if loc2(1,j) > 0 && loc2(2,j) > 0 && loc2(1,j) <= c1 && loc2(2,j) <= r1
            tem_img2(j,:) = [img2(loc2(2,j),loc2(1,j),1),img2(loc2(2,j),loc2(1,j),2),img2(loc2(2,j),loc2(1,j),3)];
        else
            tem_img2(j,:) = [0,0,0];
        end
    end
    tem_img1 = reshape(img1,pix_num,3);
    dis = sqrt(sum((tem_img1-tem_img2).^2,2));
    dis = reshape(dis,r1,c1);
    L(:,:,i) = sigma./(sigma+dis); %pc
    
end
[u,initial_term] = max(L,[],3);
initial_term = reshape(initial_term,1,pix_num)-1;
u = 1./u;
data_term = 1-u.*L;
data_term = reshape(data_term,pix_num,len_d)';
%% prior_term
lambda = zeros(1,4*pix_num);
idx2 = 0;
location = zeros(2,4*pix_num);
for c = 1 : c1
    for r = 1 : r1
        idx2 = idx2 + 1;
        location(1,4*(idx2-1)+1:4*idx2) = idx2;
        if r<r1
            location(2,4*(idx2-1)+1) = idx2+1; 
            lambda(4*(idx2-1)+1) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r+1,c,:),1,3));
        end
        if r>1
            location(2,4*(idx2-1)+2) = idx2-1; 
            lambda(4*(idx2-1)+2) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r-1,c,:),1,3));
        end
        if c < c1
            location(2,4*(idx2-1)+3) = idx2+r1;
            lambda(4*(idx2-1)+3) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r,c+1,:),1,3));
        end
        if c > 1
            location(2,4*idx2) = idx2-r1;
            lambda(4*idx2) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r,c-1,:),1,3));
        end 
    end
end
index = 1:4*pix_num;
index = index(all(location));
location = location(:,index);%remove location with 0
lambda = lambda(:,index);%remove relative part
lambda = 1./(lambda+epsilon);
prior_term = sparse(location(1,:),location(2,:),lambda,pix_num,pix_num);
%% labelcost
[dx,dy] = meshgrid(1:len_d,1:len_d);
labelcost = min(abs(dx-dy),0.05*(len_d-1));
%%
label = GCMex(initial_term,single(data_term),prior_term,single(labelcost),0);
label = reshape(label,r1,c1);
imshow(uint8(label),[0,max(label(:))])