clear
clc
addpath(genpath('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/GCMex'));
img1 = double(imread('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/im6.png'));
img2 = double(imread('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/im2.png'));
[r1,c1,d1] = size(img1);
[r2,c2,d2] = size(img2);
pix_num = r1*c1;
disparity = 1:1:0.2*c1;
%disparity = 1:1:100;
len_d = length(disparity);
data_term = zeros(len_d,pix_num);
initial_term = ones(1,pix_num);
%% data_term
for i = 1 : len_d
    a = disparity(i);
    rec_img = zeros(r2,c2,d2);
    rec_img(:,1:c2-a,:) = img2(:,a+1:c2,:);
    rec_img(:,c2-a+1:c2,:) = zeros(r2,a,d2);
    dis_matrix = sqrt(sum((img1 - rec_img).^2,3));
    dis_matrix = reshape(dis_matrix,1,pix_num);
    data_term(i,:) = dis_matrix;
end

%% prior_term
lambda = 120;
idx2 = 0;
location = zeros(2,4*pix_num);
for r = 1 : r1
    for c = 1 : c1
        idx2 = idx2 + 1;
        location(1,4*(idx2-1)+1:4*idx2) = idx2;
        %if r<r1, location(2,4*(idx2-1)+1) = idx2+c1; end
        %if r>1, location(2,4*(idx2-1)+2) = idx2-c1; end
        if c < c1, location(2,4*(idx2-1)+3) = idx2+1;end
        if c > 1, location(2,4*idx2) = idx2-1;end 
    end
end
index = 1:4*pix_num;
location = location(:,index(all(location)));%remove location with 0
prior_term = sparse(location(1,:),location(2,:),lambda,pix_num,pix_num); 

[dx,dy] = meshgrid(1:len_d,1:len_d);

labelcost = min(abs(dx-dy), 0.05*(max(disparity)-min(disparity)));
%labelcost = abs(dx-dy);
label = GCMex(initial_term,single(data_term),prior_term,single(labelcost));
label = reshape(label,r1,c1);
imshow(label,[])


 