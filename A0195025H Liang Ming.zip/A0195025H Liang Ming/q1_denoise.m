clear
clc
addpath(genpath('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/GCMex'));
raw_im = im2double(imread('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/bayes_in.jpg'));
foreground = [0,0,255];%blue
background = [245,210,110]; %yellow
[row,col,dim] = size(raw_im);
%% data term
pix_num = row*col; %number of all pixels
initial_term = ones(1,pix_num);
data_term = zeros(2,pix_num);
idx1 = 0;
for i = 1 : row
    for j = 1 : col
        idx1 = idx1 + 1;
        vec = [raw_im(i,j,1),raw_im(i,j,2),raw_im(i,j,3)];
        data_term(1,idx1) = sum(abs(vec-background/255));
        data_term(2,idx1) = sum(abs(vec-foreground/255));
        if data_term(1,idx1) > data_term(2,idx1)
            initial_term(idx1) = 1;
        else
            initial_term(idx1) = 0;
        end
    end
end

%% prior term
lambda = 7; %lambda factor
idx2 = 0;
%prior_term = sparse(row*col,row*col);
location = zeros(2,4*pix_num);
for r = 1 : row
    for c = 1 : col
        idx2 = idx2 + 1;
        location(1,4*(idx2-1)+1:4*idx2) = idx2;
        if r<row, location(2,4*(idx2-1)+1) = idx2+col; end
        if r>1, location(2,4*(idx2-1)+2) = idx2-col; end
        if c < col, location(2,4*(idx2-1)+3) = idx2+1;end
        if c > 1, location(2,4*idx2) = idx2-1;end 
    end
end
index = 1:4*pix_num;
location = location(:,index(all(location)));%remove location with 0
prior_term = sparse(location(1,:),location(2,:),lambda,pix_num,pix_num);           
            
        
    
% for r = 1 : row
%     for c = 1 : col
%         idx2 = idx2 + 1;
% %         if idx2 ==1
% %             prior_term(idx2,2) = 1;
% %             prior_term(idx2,1+col) = 1;
% %         elseif idx2 == col
% %             prior_term(idx2,col-1) = 1;
% %             prior_term(idx2,2*col) = 1;
% %         elseif idx2 == ((row-1)*col+1)   
% %             prior_term(idx2,idx2-col) = 1;
% %             prior_term(idx2,idx2+1) = 1;
% %         elseif idx2 == row*col
% %             prior_term(idx2,idx2-col) = 1;
% %             prior_term(idx2,idx2-1) = 1;
% %         elseif r == 1
% %             prior_term(idx2,idx2-1) = 1;
% %             prior_term(idx2,idx2+1) = 1;
% %             prior_term(idx2,idx2+col) = 1;
% %         elseif r == row
% %             prior_term(idx2,idx2-1) = 1;
% %             prior_term(idx2,idx2+1) = 1;
% %             prior_term(idx2,idx2-col) = 1;
% %         elseif c == 1
% %             prior_term(idx2,idx2-col) = 1;
% %             prior_term(idx2,idx2+col) = 1;
% %             prior_term(idx2,idx2+1) = 1;
% %         elseif c == col
% %             prior_term(idx2,idx2-col) = 1;
% %             prior_term(idx2,idx2+col) = 1;
% %             prior_term(idx2,idx2-1) = 1;
% %         else
% %             prior_term(idx2,idx2-col) = 1;
% %             prior_term(idx2,idx2+col) = 1;
% %             prior_term(idx2,idx2-1) = 1;
% %             prior_term(idx2,idx2+1) = 1;
% %         end
%         if r<row, prior_term(idx2,idx2+col) = lambda; end
%         if r>1, prior_term(idx2,idx2-col) = lambda; end
%         if c < col, prior_term(idx2,idx2+1) = lambda;end
%         if c > 1, prior_term(idx2,idx2-1) = lambda;end           
%     end
% end    
[dx,dy] = meshgrid(1:2,1:2);
labelcost = abs(dx-dy);
label = GCMex(initial_term,single(data_term),prior_term,single(labelcost));
label = reshape(label,[col,row])';
finalimage = zeros(row,col,dim);
%% restore the image
for i = 1 : dim
    for j = 1 : row
        for k = 1 : col
            if label(j,k) == 1
                finalimage(j,k,i) = foreground(i);
            else
                finalimage(j,k,i) = background(i);
            end
        end
    end
end              
imshow(finalimage/255)

            
        
            
        
