clear
clc
addpath(genpath('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/GCMex'));
%cameras = load('/Users/frankie/Documents/MATLAB/Visual Computing/assg2/cameras.txt');
camera_path = '/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework2/Road/cameras.txt';
camera_para = loadCamParas(camera_path);
dmin = 0;
dmax = 0.01;
m = 100;
disparity = zeros(m+1,1);
for k = 0 : 100
    disparity(k+1) = (m-k)/m*dmin + k/m* dmax;
end
%% input images
image_path = '/Users/frankie/Downloads/EE module/Semester2/Visual Computing/homework2/Road/src';
images = dir(sprintf('%s/*.jpg', image_path));
[row,col,~] = size(imread(fullfile(image_path,images(1).name)));
pix_num = row*col;
sigma_c = 10;
sigma_d = 3;
len_d = length(disparity);
%omiga = 200;
%eta = 0.05*(len_d-1);
epsilon = 5;
%% start
% tem_images{1}:Ҫ�������ͼ��
% tem_images��������������Ϊ�ο���ͼ��
for num = 40:41
    neibour_imageidx = num-4:num+4;
    neibour_imageidx(neibour_imageidx<1) = [];
    neibour_imageidx(neibour_imageidx>len_d) = [];
    neibour_imageidx(neibour_imageidx==num) = [];
    len_n = length(neibour_imageidx);
    tem_images = cell(len_n,1);
    tem_images{1} = double(imread(fullfile(image_path,images(num).name)));
    for i = 1 : len_n
        tem_path = fullfile(image_path,images(neibour_imageidx(i)).name);
        tem_images{i+1} = double(imread(tem_path));
    end  
    %% data_term
    [x,y] = meshgrid(1:col,1:row);
    loc = ones(3,pix_num);
    loc(1,:) = reshape(x,1,pix_num); %img column location 960
    loc(2,:) = reshape(y,1,pix_num);%img row location 540
    K1 = camera_para.K{num};
    R1 = camera_para.R{num};
    T1 = camera_para.T{num};
    %img_list = [1,2,4,5];
    L_final = zeros(row,col,len_d);
    img1 = tem_images{1};
    for rho = 1 : len_n
        idx1 = neibour_imageidx(rho);
        K2 = camera_para.K{idx1};
        R2 = camera_para.R{idx1};
        T2 = camera_para.T{idx1};
        img2 = tem_images{rho+1};
        L = zeros(row,col,len_d); %L_init
        for i = 1 : len_d
            loc2 = K2*R2'*R1/K1*loc+disparity(i).*K2*R2'*(T1-T2);
            loc3 = K1*R1'*R2/K2*loc2+disparity(i).*K1*R1'*(T2-T1);
            loc2 = loc2./loc2(3,:);
            loc3 = loc3./loc3(3,:);
            loc2 = round(loc2); % relative location in img2
            loc3 = round(loc3); % pv location
            tem_img2 = zeros(pix_num,3);
            for j = 1 : length(loc2')
                if loc2(1,j) > 0 && loc2(2,j) > 0 && loc2(1,j) <= col && loc2(2,j) <= row
                    tem_img2(j,:) = [img2(loc2(2,j),loc2(1,j),1),img2(loc2(2,j),loc2(1,j),2),img2(loc2(2,j),loc2(1,j),3)];
                else
                    tem_img2(j,:) = [0,0,0];
                end
                if loc3(1,j) <= 0||loc3(1,j)>col, loc3(1,j) = 0;end
                if loc3(2,j) <= 0||loc3(2,j)>row, loc3(2,j) = 0;end
            end
            tem_img1 = reshape(img1,pix_num,3);
            dis = sqrt(sum((tem_img1-tem_img2).^2,2));
            dis = reshape(dis,row,col);
            delta_loc = loc-loc3;
            pv = exp(-(delta_loc(1,:).^2+delta_loc(2,:).^2)/(2*sigma_d^2));
            pv = reshape(pv,row,col);
            pc = sigma_c./(sigma_c+dis);
            L(:,:,i) = pc.^pv;
            %L(:,:,i) = sigmac./(sigmac+dis); %pc
            % ����pv, pv*pc
        end
        L_final = L + L_final;
    end
    [u,initial_term] = max(L_final,[],3);
    u = 1./u;
    data_term = 1-u.*L_final;
    data_term = reshape(data_term,pix_num,len_d)';
    %% prior_term
    lambda = zeros(1,8*pix_num);
    idx2 = 0;
    location = zeros(2,8*pix_num);
    for c = 1 : col
        for r = 1 : row
            idx2 = idx2 + 1;
            location(1,8*(idx2-1)+1:8*idx2) = idx2;
            if r<row
                location(2,8*(idx2-1)+1) = idx2+1;
                lambda(8*(idx2-1)+1) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r+1,c,:),1,3));
                if c < col
                    location(2,8*(idx2-1)+2) = idx2+1+row;
                    lambda(8*(idx2-1)+2) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r+1,c+1,:),1,3));
                end
                if c > 1
                    location(2,8*(idx2-1)+3) = idx2+1-row;
                    lambda(8*(idx2-1)+3) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r+1,c-1,:),1,3));
                end
            end
            if r>1
                location(2,8*(idx2-1)+4) = idx2-1;
                lambda(8*(idx2-1)+4) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r-1,c,:),1,3));
                if c > 1
                    location(2,8*(idx2-1)+5) = idx2-1-row;
                    lambda(8*(idx2-1)+5) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r-1,c-1,:),1,3));
                end    
                if c < col
                    location(2,8*(idx2-1)+6) = idx2-1+row;
                    lambda(8*(idx2-1)+6) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r-1,c+1,:),1,3));
                end
            end
            if c < col
                location(2,8*(idx2-1)+7) = idx2+row;
                lambda(8*(idx2-1)+7) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r,c+1,:),1,3));
            end
            if c > 1
                location(2,8*(idx2+1)) = idx2-row;
                lambda(8*(idx2+1)) = norm(reshape(img1(r,c,:),1,3)-reshape(img1(r,c-1,:),1,3));
            end
        end
    end
    index = 1:8*pix_num;
    index = index(all(location));
    location = location(:,index);%remove location with 0
    lambda = lambda(:,index);%remove relative part
    lambda = 1./(lambda+epsilon);
    prior_term = sparse(location(1,:),location(2,:),lambda,pix_num,pix_num);
    %% labelcost
    [dx,dy] = meshgrid(1:len_d,1:len_d);
    labelcost = min(abs(dx-dy),0.05*(len_d-1));
    %%
    initial_term = reshape(initial_term,1,pix_num)-1;
    label = GCMex(initial_term,single(data_term),prior_term,single(labelcost),0);
    label = reshape(label,row,col);
    figure(num)
    imshow(uint8(label),[0,max(label(:))])
end    
function [ camPara ] = loadCamParas( para_file )
    para_file = fopen(para_file);
    frame_num = fscanf(para_file, '%d', 1);
    K_cell = cell(frame_num, 1);
    R_cell = cell(frame_num, 1);
    T_cell = cell(frame_num, 1);
    for fi = 1:frame_num
        K_cell{fi} = fscanf(para_file, '%f', [3,3])';
        R_cell{fi} = fscanf(para_file, '%f', [3,3])';
        T_cell{fi} = fscanf(para_file, '%f', [1,3])';
    end
    fclose(para_file);
    camPara.K = K_cell;
    camPara.R = R_cell;
    camPara.T = T_cell;
end

